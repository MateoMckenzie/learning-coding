from inputs import a, b
from processing import multiply
answer = multiply (b,a)
print(answer)

second_answer = multiply(answer, 120)
print(second_answer)

