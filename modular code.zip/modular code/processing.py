def multiply(value_a, value_b):
    return value_a * value_b
